# Invoice Management System - Requirements Document

## 🎯 Project Overview

An intelligent, automated invoice management system that processes purchase invoices through Telegram, performs OCR extraction, validates data using AI, and maintains synchronized Google Sheets records with banking ledger integration.

---

## 📋 Functional Requirements

### FR-1: Multi-Channel Input Processing
**Priority:** Critical  
**Description:** The system must accept invoice data through multiple channels:
- 📸 Image uploads (PNG, JPEG) via Telegram
- 📄 PDF documents via Telegram
- 💬 Text-based conversations for manual entry
- 📝 Web forms for structured data entry

**Acceptance Criteria:**
- Support for image formats: PNG, JPEG
- Support for PDF documents (single and multi-page)
- Real-time processing confirmation within 3 seconds
- Graceful error handling for unsupported formats

---

### FR-2: Optical Character Recognition (OCR)
**Priority:** Critical  
**Description:** Extract text content from uploaded images and PDFs using Google Vision API

**Acceptance Criteria:**
- Accuracy rate ≥ 95% for printed invoices
- Multi-page PDF support with page-wise text extraction
- Text aggregation across all pages
- Error detection and reporting for unreadable documents

**Technical Specifications:**
- API: Google Vision API (DOCUMENT_TEXT_DETECTION)
- Image processing: Base64 encoding
- PDF processing: Multi-page batch processing
- Character count tracking per page

---

### FR-3: AI-Powered Data Extraction
**Priority:** Critical  
**Description:** Use DeepSeek LLM to intelligently extract structured invoice data from OCR text

**Extracted Fields:**
| Category | Fields |
|----------|--------|
| **Invoice Metadata** | Invoice Number, Invoice Date, Due Date, Currency |
| **Vendor Information** | Name, Address, Phone, Email, GST/Tax ID |
| **Customer Information** | Name, Address, Phone, Email |
| **Line Items** | Description, Quantity, Unit, Unit Price, Amount, Tax Rate |
| **Financial Totals** | Subtotal, Tax Amount, Discount, Shipping, Grand Total |
| **Payment Details** | Payment Status, Method, Paid Amount, Remaining Amount |
| **Banking Info** | Bank Name, Account Number, IFSC Code |

**Validation Rules:**
- ✅ Never guess or infer missing data
- ✅ Extract values exactly as written on invoice
- ✅ Return `null` for unavailable fields
- ✅ Validate payment calculations: `remaining_amount = total - paid_amount`
- ✅ Enforce payment status logic:
  - `Paid`: paid_amount ≥ total_amount
  - `Partial`: paid_amount < total_amount
  - `Unpaid`: no payment information

---

### FR-4: Duplicate Invoice Detection
**Priority:** High  
**Description:** Prevent duplicate invoice entries by checking existing records

**Logic:**
```
IF invoice_number EXISTS in Purchase Sheet:
    → Mark as "existing_invoice": true
    → Trigger EDIT/UPDATE workflow
ELSE:
    → Mark as "existing_invoice": false
    → Create NEW invoice entry
```

**Acceptance Criteria:**
- Check against all existing invoice numbers
- Case-insensitive matching
- Return match status in JSON response
- Route to appropriate workflow path

---

### FR-5: Banking Ledger Integration
**Priority:** High  
**Description:** Automatically create ledger entries when payment transactions occur

**Ledger Entry Triggers:**
- ✅ Paid amount added or increased
- ✅ Payment status changed
- ✅ Payment method changed

**Entry ID Generation:**
- Format: `BL-000001`, `BL-000002`, etc.
- Sequential increment from last entry
- Never skip or reuse numbers
- Start from `BL-000001` if no entries exist

**Ledger Fields:**
| Field | Description | Example |
|-------|-------------|---------|
| `entry_id` | Unique ledger ID | BL-000045 |
| `date` | Transaction date | 2024-02-15 |
| `source_type` | Transaction source | Purchase |
| `source_id` | Invoice reference | INV-2024-001 |
| `party` | Vendor/Customer name | ABC Suppliers Ltd |
| `direction` | Money flow | OUT (purchase) / IN (sales) |
| `payment_method` | Payment mode | UPI, Cash, Bank Transfer |
| `amount` | Transaction amount | 15000.00 |

**Non-Triggers (No Ledger Entry):**
- ❌ Item description edits
- ❌ Invoice total corrections
- ❌ Customer details updates
- ❌ OCR re-processing

---

### FR-6: Google Sheets Synchronization
**Priority:** Critical  
**Description:** Maintain real-time synchronized records across multiple Google Sheets

**Sheets Structure:**

#### 1️⃣ Purchase Sheet
**Purpose:** Main invoice repository  
**Operations:** Append or Update (match on `invoice_number`)  
**Key Fields:** Invoice details, vendor info, items, payment status

#### 2️⃣ Sales Sheet
**Purpose:** Sales invoice tracking  
**Operations:** Read/Query for AI agent  

#### 3️⃣ Banking Ledger Sheet
**Purpose:** Financial transaction log  
**Operations:** Append only (no updates)  
**Key Fields:** entry_id, date, party, direction, amount

#### 4️⃣ Expense Sheet
**Purpose:** Expense tracking  
**Operations:** Read/Query for AI agent

#### 5️⃣ Quotation Sheet
**Purpose:** Quote management  
**Operations:** Read/Query for AI agent

**Acceptance Criteria:**
- Real-time updates within 2 seconds
- Atomic transactions (all-or-nothing)
- Error recovery with rollback capability
- Data validation before write

---

### FR-7: Document Management
**Priority:** High  
**Description:** Organize processed documents in Google Drive

**Folder Structure:**
```
📁 Root
├── 📁 unprocessed/     → Initial uploads
├── 📁 processed/       → Successfully extracted
└── 📁 error_receipt/   → Failed extractions
```

**File Naming Convention:**
```
{Date}_{Vendor}_{ReceiptID}.{extension}
Example: 2024-02-15_ABCSuppliers_INV001.pdf
```

**Workflow:**
1. Upload → `unprocessed/`
2. OCR Success → Move to `processed/` + Rename
3. OCR Failure → Move to `error_receipt/`

---

### FR-8: Conversational AI Agent
**Priority:** Medium  
**Description:** Telegram chatbot for querying and managing invoice data

**Capabilities:**
- 📊 Query invoice status
- 💰 Check payment history
- 📈 Generate financial reports
- 🔍 Search transactions
- 📝 Answer accounting questions

**AI Configuration:**
- **Model:** DeepSeek Chat
- **Memory:** 10-message context window
- **Session:** User-specific (by Telegram ID)
- **Tools:** Google Sheets read access to all 5 sheets

**Personality:**
- Professional accountant persona
- Plain text responses
- Emoji usage for engagement
- Data-driven answers only

---

### FR-9: User Interface - Telegram Bot
**Priority:** Critical  
**Description:** Interactive menu system for quick actions

**Main Menu Options:**
```
┌─────────────────────────────────────┐
│  📝 Purchase (text) │  💵 Sales     │
├─────────────────────────────────────┤
│  📋 Quotation       │  💸 Expense   │
├─────────────────────────────────────┤
│  ✏️  Edit           │  🏦 Banking   │
├─────────────────────────────────────┤
│  📊 Report          │  📒 Ledger    │
├─────────────────────────────────────┤
│  📄 Sales Sheet     │  🛒 Purchase  │
│  📋 Quotation       │  💸 Expense   │
└─────────────────────────────────────┘
```

**Interaction Flow:**
1. User uploads image/PDF
2. System responds: "Data is being processed..."
3. OCR + AI extraction (5-10 seconds)
4. Formatted summary with emojis
5. Confirmation of sheet update

---

## 🔒 Non-Functional Requirements

### NFR-1: Performance
- **OCR Processing:** < 10 seconds per document
- **AI Extraction:** < 5 seconds per invoice
- **Sheet Updates:** < 2 seconds per operation
- **Bot Response Time:** < 3 seconds for queries

### NFR-2: Reliability
- **Uptime:** 99.5% availability
- **Error Recovery:** Automatic retry (3 attempts)
- **Data Integrity:** Transaction-safe operations
- **Backup:** Daily Google Sheets versioning

### NFR-3: Security
- **API Keys:** Secured in n8n credentials vault
- **Access Control:** Telegram user ID verification
- **Data Privacy:** No external data sharing
- **HTTPS:** All API calls encrypted

### NFR-4: Scalability
- **Concurrent Users:** Support 50+ simultaneous requests
- **Document Queue:** Process up to 100 documents/hour
- **Sheet Capacity:** Handle 10,000+ rows per sheet
- **Storage:** Unlimited Google Drive capacity

### NFR-5: Maintainability
- **Logging:** Comprehensive error and audit logs
- **Monitoring:** n8n execution history tracking
- **Modularity:** Reusable node components
- **Documentation:** Inline comments and external docs

---

## 🔄 System Integrations

| Service | Purpose | Authentication |
|---------|---------|----------------|
| **Telegram API** | User interface & bot | Bot token |
| **Google Vision API** | OCR processing | API key |
| **DeepSeek AI** | Data extraction & chatbot | API credentials |
| **Google Sheets API** | Data storage | OAuth2 |
| **Google Drive API** | Document management | OAuth2 |

---

## 🚨 Edge Cases & Error Handling

### EC-1: Unreadable Documents
**Scenario:** OCR returns empty/null text  
**Action:** Move to `error_receipt/`, notify user, prompt re-upload

### EC-2: Ambiguous Payment Status
**Scenario:** Caption unclear ("paid some amount")  
**Action:** Mark as `Partial`, set `paid_amount = null`, request clarification

### EC-3: Missing Invoice Number
**Scenario:** No invoice number detected  
**Action:** Generate temporary ID `TEMP-{timestamp}`, flag for manual review

### EC-4: Duplicate Detection Conflict
**Scenario:** Same invoice number, different amounts  
**Action:** Create new entry with `-R{revision}` suffix, alert user

### EC-5: Network Failures
**Scenario:** Google API timeout  
**Action:** Retry 3x with exponential backoff, fallback to manual entry

---

## 📊 Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| **OCR Accuracy** | ≥ 95% | Character-level comparison |
| **Processing Time** | < 15 sec | End-to-end from upload to sheet |
| **User Satisfaction** | ≥ 4.5/5 | Telegram feedback surveys |
| **Error Rate** | < 3% | Failed extractions / Total uploads |
| **Duplicate Prevention** | 100% | Zero duplicate invoice_numbers |

---

## 🔮 Future Enhancements (Out of Scope v1.0)

- 📧 Email integration for invoice ingestion
- 🌍 Multi-language OCR support (Hindi, Marathi)
- 📈 Advanced analytics dashboard
- 🤖 Automated payment reminders
- 📱 Mobile app (iOS/Android)
- 🔗 ERP system integration (Tally, QuickBooks)
- 🧾 Receipt printer integration
- 📊 Custom report builder

---

## 📞 Stakeholders

| Role | Responsibility |
|------|----------------|
| **End Users** | Upload invoices, query data |
| **Accountant** | Review and validate entries |
| **System Admin** | Monitor n8n workflows |
| **Developer** | Maintain and enhance system |

---

## 📝 Glossary

- **OCR:** Optical Character Recognition - technology to extract text from images
- **LLM:** Large Language Model - AI for understanding and generating text
- **GST:** Goods and Services Tax - Indian tax system
- **IFSC:** Indian Financial System Code - bank branch identifier
- **Ledger:** Systematic record of financial transactions
- **n8n:** Workflow automation platform
- **Webhook:** Automated message sent from apps when event occurs

---

**Document Version:** 1.0  
**Last Updated:** February 15, 2026  
**Author:** System Documentation Team  
**Status:** ✅ Approved for Implementation
